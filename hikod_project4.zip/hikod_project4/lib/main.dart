import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final apiKey = '5a350c125fmshff07f1eeaecbd29p194beejsnef99e431afad';
  final cities = ["Istanbul", "New York", "London", "Paris", "Tokyo"];

  Future<List<WeatherData>> getWeatherData() async {
    final List<WeatherData> weatherList = [];

    for (final city in cities) {
      try {
        final response = await http.get(
          Uri.parse('https://weatherapi-com.p.rapidapi.com/current.json?q=$city'),
          headers: {
            'X-RapidAPI-Key': apiKey,
            'X-RapidAPI-Host': 'weatherapi-com.p.rapidapi.com',
          },
        ).timeout(const Duration(seconds: 5));


        if (response.statusCode == 200) {
          final Map<String, dynamic> data = json.decode(response.body);
          final weatherData = WeatherData.fromMap(data);
          weatherList.add(weatherData);
          print('Data fetched for $city: $data');
        } else {
          print('Error fetching data for $city: ${response.statusCode}');
          print('Response body: ${response.body}');
        }
      } catch (e) {
        print('Error fetching data for $city: $e');
      }
    }
    return weatherList;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Weather App'),
        ),
        body: FutureBuilder<List<WeatherData>?>(
          future: getWeatherData(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            } else if (snapshot.hasError || snapshot.data?.isEmpty == true) {
              return const Center(
                child: Text('Error: Weather data could not be retrieved.'),
              );
            } else {
              final weatherList = snapshot.data ?? [];
              return ListView.builder(
                itemCount: weatherList.length,
                itemBuilder: (context, index) {
                  final data = weatherList[index];
                  return Column(
                    children: [
                      ListTile(
                        title: Text('Location: ${data.city}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Sıcaklık: ${data.tempC.toStringAsFixed(1)}°C'),
                            Text('Nem: ${data.humidity}%'),
                            Text('Rüzgar Hızı: ${data.windSpeed.toStringAsFixed(1)} kph'),
                          ],
                        ),
                      ),
                      if (index < weatherList.length - 1) const Divider(),
                    ],
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}

class WeatherData {
  final String city;
  final double tempC;
  final int humidity;
  final double windSpeed;

  WeatherData({
    required this.city,
    required this.tempC,
    required this.humidity,
    required this.windSpeed,
  });

  factory WeatherData.fromMap(Map<String, dynamic> map) {
    final current = map['current'];
    final location = map['location'];
    final city = location['name'];
    final tempC = current['temp_c']?.toDouble() ?? 0.0;
    final humidity = current['humidity'] ?? 0;
    final windSpeed = current['wind_kph']?.toDouble() ?? 0.0;
    return WeatherData(city: city, tempC: tempC, humidity: humidity, windSpeed: windSpeed);
  }
}
