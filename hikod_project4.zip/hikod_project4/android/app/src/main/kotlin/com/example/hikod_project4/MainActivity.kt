package com.example.hikod_project4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
